# WhatsApp Private con teléfonos ocultos

Versión de Windows: `1.7.0`.

Abre `WhatsApp Private.exe`. La protección está activa desde el inicio; el indicador «Teléfonos y copia protegidos» está oculto para mantener limpia la interfaz. Requiere Windows 10/11 de 64 bits y Microsoft Edge WebView2 Runtime.

## Teléfonos y portapapeles

Los números detectados se cubren con puntos discretos en textos, campos editables y tooltips. También se ocultan en las notificaciones generadas por la app. Los mensajes y valores originales se conservan: la personalización no modifica el contenido enviado.

Cuando una selección toca un teléfono oculto, copiar devuelve `[Teléfono oculto]`, incluso si se selecciona un solo dígito. La protección también se aplica al menú Copiar de la app, a Clipboard API y al arrastre de selecciones o enlaces protegidos. Cortar una selección protegida conserva el borrador. El texto normal sigue siendo copiable.

La detección no reconoce números dentro de imágenes, vídeos ni documentos. Puede cubrir otros números largos, como identificadores o importes. Es una protección de interfaz, no un cifrado ni un control de acceso frente a quien pueda inspeccionar el perfil o modificar el programa. No cambia el contenido que ya exista en el portapapeles de Windows.

## Interfaz simplificada

Se ocultan mediante CSS y marcas en el DOM, conservando el código y las funciones:

- Contacto, dentro del menú de adjuntos `+`.
- El botón de stickers/emojis del campo de escritura del chat.
- La barra adicional de cuentas de WhatsApp Private.
- Estados, Canales, Comunidades, Meta AI y su separador.
- Enviar comentarios, Contenido multimedia, Beta, Tú y los engranajes de ajustes.
- Menú y Nuevo chat en la cabecera de la lista de chats.
- Menú de tres puntos en la cabecera de cada conversación; también se bloquea su activación.
- Los accesos de inicio Add contact/Añadir contacto e Invite a friend/Invitar a un amigo. Send document/Enviar documento y New call/Nueva llamada permanecen visibles.

Chats permanece visible. En WhatsApp Business se ocultan también los accesos laterales de Llamadas, herramientas de empresa y publicidad. Los adjuntos y los menús de cada mensaje se conservan. Los ajustes de WhatsApp Private siguen accesibles con `Ctrl+,`.

Las reglas están en `assets/phone_privacy.js`. Para restaurar un control, retira su regla o marcador de ocultación y recompila. WhatsApp puede cambiar los nombres o la estructura de sus elementos, por lo que estas reglas podrían requerir mantenimiento.

## Llamadas

La app utiliza WhatsApp Web con la identidad real de WebView2 en Windows. La disponibilidad de llamadas depende de las funciones habilitadas por WhatsApp para la sesión. La opción oficial de versión beta permitió mostrar Llamadas en la sesión comprobada; esa configuración no viaja con el repositorio ni con el ejecutable. No se fuerzan indicadores internos de WhatsApp.

Se comprobó la interfaz de llamadas. Audio y vídeo requieren una prueba real del usuario.

## Perfil y actualizaciones

El perfil permanece local en `%APPDATA%\WhatsAppDesk\UserData`. El repositorio y la descarga no incluyen sesiones, mensajes, contactos, credenciales ni capturas de tus conversaciones. En otro PC debes vincular tu cuenta.

No abras simultáneamente esta versión y otra copia de WhatsApp Private que use el mismo perfil. El actualizador utiliza únicamente el canal de WhatsApp Private y exige sumas SHA256. Descarga versiones nuevas en segundo plano y las instala al volver a abrir, conservando el perfil. También puedes pulsar «Reiniciar y actualizar». Consulta [la guía de publicación](ACTUALIZACIONES.md).

## Verificación

Se aprobaron las pruebas específicas de redacción y actualización, y las pruebas de navegador con datos ficticios: texto original intacto, campos editables, contenido dinámico, tooltips, selección, copia completa y parcial, corte, Clipboard API, formatos HTML, menú contextual y arrastre. Las pruebas no usan el perfil ni el portapapeles real del usuario. La suite general heredada conserva pruebas de rutas y logs pendientes de adaptar a Windows.

Proyecto independiente basado en [vianziro/Whatsapp-Dekstop](https://github.com/vianziro/Whatsapp-Dekstop), bajo la licencia MIT incluida. No es una aplicación oficial de WhatsApp o Meta.
